package dinesh.springframework.springmvcrest.bootstrap;

import dinesh.springframework.springmvcrest.domain.Customer;
import dinesh.springframework.springmvcrest.repositories.CustomerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapData implements CommandLineRunner {
    private final CustomerRepository customerRepository;

    public BootStrapData(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        System.out.println("Loading Customer Data");

        Customer c1 = new Customer();
        c1.setFirstname("Dinesh");
        c1.setLastname("Gaddam");
        customerRepository.save(c1);

        Customer c2 = new Customer();
        c2.setFirstname("Murthy");
        c2.setLastname("Saladi");
        customerRepository.save(c2);

        Customer c3 = new Customer();
        c3.setFirstname("Karthik");
        c3.setLastname("Ponukollu");
        customerRepository.save(c3);

       System.out.println("Customers Saved:" + customerRepository.count());

    }
}
