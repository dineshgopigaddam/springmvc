package dinesh.springframework.springmvcrest.controllers;

import karthik.springframework.springmvcrest.domain.Customer;
import karthik.springframework.springmvcrest.services.CustomerService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(CustomerController.Base_URL)
public class CustomerController {

    public static final String Base_URL = "/api/v1/customers";

    private final CustomerService customerservice;

    public CustomerController(CustomerService customerservice) {
        this.customerservice = customerservice;
    }
    @GetMapping
    List<Customer> getAllCustomers(){
        return customerservice.findAllCustomers();
    }
    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id){
        return customerservice.findCustomerById(id);
    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Customer saveCustomer(@RequestBody Customer customer){
        return customerservice.saveCustomer(customer);
    }
}
